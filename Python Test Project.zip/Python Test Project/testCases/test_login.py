import pytest
import time
from selenium import webdriver
from pageObjects.LoginPage import LoginPage


class Test_001_Login:

    # Local Variables
    baseURL = "https://www.hudl.com"
    username = "ankitpopat07@gmail.com"
    password = "Test@123"
    incorrect_pwd = "Test"

    # Test case to verify the title of main page
    def test_mainPageTitle(self, setup):
        self.driver = setup
        self.driver.get(self.baseURL)
        act_title = self.driver.title
        self.driver.close()
        if act_title == "Hudl: We Help Teams and Athletes Win":
            assert True
        else:
            assert False
        print(" The main page title is : " + act_title)

    # Test case to verify login functionality and home page title
    def test_login(self, setup):
        self.driver = setup
        self.driver.get(self.baseURL)
        self.lp = LoginPage(self.driver)
        self.lp.clickLogin()
        self.lp.setUserName(self.username)
        self.lp.setPassword(self.password)
        self.lp.submitLogin()
        time.sleep(5)
        act_title = self.driver.title
        if act_title == "Home - Hudl":
            assert True
        else:
            assert False
        print(" The home page title is : " + act_title)
        self.driver.close()

    # Test case to verify invalid login using invalid credentials
    def test_invalid_login(self, setup):
        self.driver = setup
        self.driver.get(self.baseURL)
        self.lp = LoginPage(self.driver)
        self.lp.clickLogin()
        self.lp.setUserName(self.username)
        self.lp.setPassword(self.incorrect_pwd)
        self.lp.submitLogin()
        time.sleep(5)
        error_msg = self.driver.find_element_by_css_selector('div.login-error-container').text
        if error_msg == "We didn't recognize that email and/or password. Need help?":
            assert True
        else:
            assert False
        self.driver.close()
        print(" The error message is : " + error_msg)






