from selenium import webdriver
import pytest


@pytest.fixture()
def setup():
    driver = webdriver.Chrome(executable_path="C:/Users/APT4/PycharmProjects/pythonProject/testCases/chromedriver.exe")
    return driver
